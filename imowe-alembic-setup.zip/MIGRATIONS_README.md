# Database changes with Alembic (and backups)

Why: until now the app adds new tables by itself on startup, and `migrations_lite.py` handles a few
extra columns. That works for small changes. Alembic is the careful way to change existing tables
(add a column, rename, change a type) with a written, reviewable history and the ability to roll back.

## One-time setup (about 10 minutes)

1. Put these in your repo root, next to the `app` folder: `alembic.ini`, the `alembic/` folder, `backup_db.py`.
2. Add `alembic` on its own line in `requirements.txt` and install it: `pip install alembic`.
3. Make your computer able to reach the real database, the same way the app does
   (set the same `DATABASE_URL` variable in your terminal).
4. **Back up first:** `python backup_db.py`  (also press your database provider's backup/snapshot button if it has one).
5. Mark the database as "up to date with the baseline": `alembic stamp head`
   (this only writes a small `alembic_version` table; it changes none of your data).
6. Check: `alembic current` should print `0001_baseline (head)`.

Leave `Base.metadata.create_all` and `migrations_lite.run` in `main.py` for now. They keep working.

## Every time you change a table later

Rule of thumb: **brand-new tables** can still be created by the app on startup. **Changes to an
existing table** (new column, changed type, new index) go through Alembic.

1. Edit the model in `models.py`.
2. `python backup_db.py`
3. `alembic revision --autogenerate -m "add phone number to users"`
4. **Open the new file in `alembic/versions/` and read it.** Autogenerate is a first draft. Delete anything
   you didn't intend (it sometimes wants to drop things). For a new NOT NULL column on a table that already
   has rows, give it a `server_default` so existing rows get a value.
5. `alembic upgrade head`
6. Deploy the new code.

## Rolling back

- Undo the last change: `alembic downgrade -1` (works if the `downgrade()` in that file is filled in; autogenerate fills it in for simple changes).
- If something is badly wrong: restore from the provider's snapshot, or use the zip from `backup_db.py` (one JSON record per line per table; ask me and I'll write a restore script if you ever need it).

## Habits that keep you safe

- Never run a migration on the live database without a fresh backup from the same day.
- Try risky changes against a copy of the database first if your provider lets you make one (a "branch" or "fork").
- Commit the new file in `alembic/versions/` together with the model change.
